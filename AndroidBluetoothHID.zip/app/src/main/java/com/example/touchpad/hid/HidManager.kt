
package com.example.touchpad.hid

class HidManager {
    // Bluetooth HID logic placeholder
}
