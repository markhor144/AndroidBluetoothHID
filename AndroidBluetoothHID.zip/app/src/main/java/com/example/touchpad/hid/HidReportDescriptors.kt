
package com.example.touchpad.hid

object HidReportDescriptors {
    // Mouse + keyboard descriptors
}
