
package com.example.touchpad.ui

import androidx.compose.runtime.Composable

@Composable
fun KeyboardView() {
    // On-screen keyboard UI
}
