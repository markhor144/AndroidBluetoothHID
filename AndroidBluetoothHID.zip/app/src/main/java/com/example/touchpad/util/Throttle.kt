
package com.example.touchpad.util

class Throttle {
    // Event throttling helper
}
