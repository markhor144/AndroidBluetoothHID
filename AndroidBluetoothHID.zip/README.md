# Android Bluetooth HID Touchpad
Production-ready Android app turning your phone into a Bluetooth mouse + keyboard.
